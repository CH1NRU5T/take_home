package com.example.take_home

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
